--=============================
  --CHANGE OVER TIME ANALYSIS
--=============================
Select 
datepart(year,order_date) as Years,
sum(sales_amount) as Total_sales,
count(customer_key) as Total_customers,
sum(quantity) as total_quantity
from gold.fact_sales 
where order_date is not null
group by datepart(year,order_date)
order by years 

-- Total sales per month and running total over time
select 
order_date,
total_sales,
sum(total_sales) over( order by  order_date) as Running_total
from
	(Select 
	datetrunc(month,order_date) as order_date,
	sum(sales_amount) as Total_sales
	from gold.fact_sales 
	where order_date is not null
	group by datetrunc(month,order_date))t

--===============================================
      --PERFORMANCE ANALYSIS
--===============================================

--Analyze year performance of product by comparingtheir sales to both average and pervious year sales. 

with yearly_sales_product as 
(select 
Year(s.order_date) as Order_Year,
p.product_name,
Sum(s.sales_amount) as Current_sales
from gold.fact_sales as s
left join gold.dim_products as p
on s.product_key = p.product_key
where Year(s.order_date) is not null
group by Year(s.order_date),p.product_name)


select 
	Order_Year,
	product_name,
	current_sales,
	Avg(current_sales) over ( partition by product_name ) as Avg_sales,
	current_sales - Avg(current_sales) over ( partition by product_name ) as Avg_diff,
	Case when current_sales - Avg(current_sales) over ( partition by product_name ) > 0 then 'Above Average'
	when current_sales - Avg(current_sales) over ( partition by product_name ) < 0 Then 'Below Average'
	Else 'Average' 
	End as Avg_change,
	Lag(current_sales) over(partition by product_name order by Order_year) as Py_sale,
	current_sales - Lag(current_sales) over(partition by product_name order by Order_year) as Py_diff,
	Case when current_sales -  Lag(current_sales) over(partition by product_name order by Order_year) > 0 then 'Increase'
	when current_sales -  Lag(current_sales) over(partition by product_name order by Order_year) < 0 Then 'decrease'
	Else 'NO change'
	End as Py_change
from yearly_sales_product
order by product_name, Order_year 

--==============================================
   -- Part-to-whole Analysis
--==============================================

--let find which categories is contributes most to sales.


With Total_Sales_category as (select 
p.category,
sum(s.sales_amount)  as Total_sales
from gold.fact_sales as s
left join gold.dim_products as p
on s.product_key = p.product_key
group by p.category)

select 
category,
total_sales,
Sum(total_sales) over() as overall_sales,
concat(Round((cast(Total_sales as Float)/ Sum(total_sales) over() )*100,2),'%') as Percentage_Contri
from Total_Sales_category



--============================================
   --Data segmentation
--===========================================

--segment products in cost range, Count how many products fall in segment

with cost_segment as (
select
	product_key,
	product_name,
	cost,
	case when cost < 500 then 'below 500'
	when cost between 500 and 1000 then '500-1000'
	when cost between 1000 and 1500 then '1000-1500'
	else 'above 1500'
	End as cost_range
	from gold.dim_products)

select 
Cost_range,
count(product_key) as Total_Products
from cost_segment
group by cost_range

--=============================================
/*group the customer based on their spending behvaiour
 VIP- Timespan atleast 12 month spend more than 5000
 Regualr - timespan atleast 12 month  and spend 5000 or less
 New - Timespan less than 12 month
 Find the total no. of customer in each group */

  with Customer_segments as (select 
 c.customer_key,
 sum(s.sales_amount) as Total_spedning,
 min(order_date) as first_order,
 max(order_date) as Last_order,
 datediff(month,min(order_date), max(order_date)) as Lifespan,
 Case when sum(s.sales_amount) >5000 And datediff(month,min(order_date), max(order_date)) >= 12 then 'VIP'
when  sum(s.sales_amount) <= 5000 And datediff(month,min(order_date), max(order_date)) >= 12 then 'regular'
else 'NEW' 
end as Group_segment
 from gold.fact_sales as s
 left join gold.dim_customers as c
 on s.customer_key = c.customer_key
 group by c.customer_key)

 select 
 Group_segment,
count(customer_key) as Customer_total

from customer_segments
group by group_segment
order by Customer_total desc


