/*
========================================================
Customer report
========================================================
Purpose:
       - This report consolidates key customer metrics and behvaiors

       Highlights:
          1. Gathers essential fields such as name, ages and transactin details.
          2. Segments customers into categories (VIP, REGULAR, NEW)  and age groups.
          3. Aggregates customer level metrics:
               - Total orders
               -Totoal sales
               -Total quantity purchased
               -Total products
               -lifespan( in months)
          4. Calculates valuable KPI:
                -recency(months since last order)
                -average order value
                -average monthly spend

            */

--1. Base query to retrieve core columns from tables
CREATE VIEW gold.report_customer as 
WITH base_query as 
(select 
s.order_number,
s.product_key,
s.order_date,
s.sales_amount,
s.quantity,
c.customer_key,
c.customer_number,
concat(c.first_name,' ', c.last_name) as Customer_Name,
datediff(year,c.birthdate,getdate()) as Age
from gold.fact_sales as s
left join gold.dim_customers as c
on c.customer_key = s.customer_key
where s.order_date is not null )

/* customer Aggregation summary */

, customer_aggregation as (
select
    customer_key,
    customer_number,
    Customer_Name,
    Age,
    count( distinct order_number) as Total_orders,
    sum(sales_amount) as Total_sales,
    sum(quantity) as Total_quantity,
    count(Distinct product_key) as Total_products,
    max(order_date) as last_order,
    datediff(month,min(order_date), max(order_date)) as Lifespan_Months
from base_query
group by 
customer_key,
customer_number,
Customer_Name,
Age
)
select 
     customer_key,
     customer_number,
     Customer_Name,
     Age,
     case when age < 20 then 'under 20'
          when age between 20 and 29 then '20-29'
          when age between 30 and 30 then '30-39'
          when age between 40 and 49 then '40-49'
          else '50 and Above'
     End as Age_group,
     Case when total_sales >5000 And Lifespan_Months >= 12 then 'VIP'
          when  Total_sales <= 5000 And Lifespan_months >= 12 then 'regular'
          else 'NEW' 
     end as customer_segment,
     last_order,
     datediff(month,last_order,getdate()) as Recency,
     Total_orders,
     Total_sales,
     Total_quantity,
     Total_products,
     Lifespan_Months,
     case when Total_orders = 0 then 0
          else total_sales/total_orders
          end as Avg_order_value,
    case when lifespan_months = 0  then total_sales
    else total_sales/Lifespan_Months
    end as Avg_monthly_spend
from customer_aggregation